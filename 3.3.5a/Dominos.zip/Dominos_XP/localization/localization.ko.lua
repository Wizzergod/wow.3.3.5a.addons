﻿--[[
	localization.koKR.lua
	translated & modified by SayClub
]]

local L = LibStub('AceLocale-3.0'):NewLocale('Dominos-XP', 'koKR')
if not L then return end

L.Texture = '무늬'
L.Width = '너비'
L.Height = '높이'
L.AlwaysShowText = '항상 문자 표시'
L.AlwaysShowXP = '항상 경험치 표시'
